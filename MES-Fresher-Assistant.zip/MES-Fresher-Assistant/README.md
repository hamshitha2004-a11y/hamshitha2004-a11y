# 🏭 MES Fresher Assistant Chatbot

> An AI-powered onboarding assistant for new MES team members — built with Streamlit, LangChain, OpenAI GPT, FAISS, and PyPDF using Retrieval-Augmented Generation (RAG).

---

## 📁 Project Structure

```
MES-Fresher-Assistant/
├── app.py                  # Main Streamlit app (UI + layout)
├── chatbot.py              # RAG chain + response generation
├── pdf_loader.py           # PDF ingestion + text chunking
├── embeddings.py           # OpenAI embeddings + FAISS management
├── related_questions.py    # Dynamic related questions engine
├── prompts.py              # All LLM prompt templates
├── requirements.txt        # Python dependencies
├── .env.example            # Environment variable template
└── data/                   # Place your PDF documents here
    └── company_docs.pdf    # (example)
```

---

## 🚀 Quick Start

### 1. Clone / Download

```bash
cd MES-Fresher-Assistant
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Set your OpenAI API key

```bash
cp .env.example .env
# Then edit .env and add your key:
# OPENAI_API_KEY=sk-your-key-here
```

Or enter it directly in the sidebar **Settings** panel when the app is running.

### 4. Add your PDF documents

Place all MES documentation PDFs inside the `./data/` folder:

```
data/
├── mes_user_guide.pdf
├── kpi_handbook.pdf
├── diss_module_docs.pdf
└── error_codes_reference.pdf
```

### 5. Run the app

```bash
streamlit run app.py
```

Open `http://localhost:8501` in your browser.

---

## 🧠 RAG Pipeline

```
PDF Documents
      ↓
Text Extraction (PyPDF)
      ↓
Text Chunking (RecursiveCharacterTextSplitter — 1000 chars, 200 overlap)
      ↓
OpenAI Embeddings (text-embedding-3-small)
      ↓
FAISS Vector Database (persisted to ./faiss_index/)
      ↓
Retriever (top-5 similarity search)
      ↓
OpenAI GPT (gpt-4o-mini by default)
      ↓
Structured Answer + Source Attribution
      ↓
Dynamic Related Questions (context-aware)
```

---

## 💡 Features

### Chat Features
- ✅ Beginner-friendly, structured responses
- ✅ Adaptive answer depth (short for factual, detailed for conceptual)
- ✅ Error code explanations (e.g. "What is error 3002?")
- ✅ Source attribution for RAG-retrieved answers
- ✅ Full chat history with clear functionality

### Dynamic Related Questions
- ✅ NO static suggestions — fully context-aware
- ✅ Topic detection via keyword + intent matching
- ✅ Question bank covers 20+ MES topics: DISS, KPI, SIM, WIP, BOM, ERP, SAP, SCADA, PLC, OEE, SPC, NCR, ECO, FMEA, Maintenance, Quality, Production, Inventory, Reporting, Training
- ✅ Topic Browser for exploring by category

### Knowledge Base
- ✅ Load PDFs from `./data/` directory
- ✅ Upload PDFs directly via sidebar
- ✅ FAISS index cached to disk (fast reload)
- ✅ Add documents without rebuilding entire index

### UI
- ✅ Dark / Light mode toggle
- ✅ Professional dashboard layout (sidebar + chat + related questions)
- ✅ Responsive and clean design
- ✅ Settings panel (API key, model selection)

---

## ⚙️ Configuration

| Setting | Default | Description |
|---|---|---|
| `OPENAI_API_KEY` | — | Required. Your OpenAI API key |
| Model | `gpt-4o-mini` | Also supports `gpt-4o`, `gpt-3.5-turbo` |
| Chunk size | `1000` chars | Configurable in `pdf_loader.py` |
| Retriever top-k | `5` chunks | Configurable in `embeddings.py` |
| FAISS index dir | `./faiss_index/` | Configurable in `embeddings.py` |

---

## 🔧 Extending the Question Bank

To add new topics to the related questions engine, edit `related_questions.py`:

```python
# 1. Add topic keywords for detection
TOPIC_KEYWORDS["YOUR_TOPIC"] = ["keyword1", "keyword2"]

# 2. Add related questions
QUESTION_BANK["YOUR_TOPIC"] = [
    "Question 1 about your topic?",
    "Question 2 about your topic?",
    ...
]

# 3. Add to priority list (optional — determines detection order)
TOPIC_PRIORITY.append("YOUR_TOPIC")
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---|---|
| `OPENAI_API_KEY not set` | Add key to `.env` file or sidebar Settings |
| No PDFs loaded | Place `.pdf` files in `./data/` and click **Load PDFs** |
| Scanned PDF — no text | Use an OCR tool first (e.g. Adobe Acrobat, `ocrmypdf`) |
| FAISS load error | Click **Rebuild** in sidebar to regenerate the index |
| Slow responses | Switch model to `gpt-3.5-turbo` in Settings |

---

## 📦 Dependencies

```
streamlit          — Web UI framework
langchain          — LLM orchestration + RAG chain
langchain-openai   — OpenAI integration for LangChain
langchain-community — FAISS vector store support
openai             — OpenAI GPT API
faiss-cpu          — Vector similarity search
pypdf              — PDF text extraction
python-dotenv      — .env file support
tiktoken           — Token counting for OpenAI models
```

---

*Built for the MES Fresher Onboarding Program.*
