"""
app.py
------
MES Fresher Assistant — Main Streamlit Application

Layout:
  ┌─────────────────────────────────────────────────────────┐
  │  Header: Branding | Dark Mode Toggle | Clear Chat       │
  ├──────────┬──────────────────────────┬───────────────────┤
  │  Sidebar │   Chat Panel (center)    │  Related Questions│
  │  History │   Messages + Cards       │  Dynamic Panel    │
  │  Settings│                          │                   │
  │  Tools   │                          │                   │
  ├──────────┴──────────────────────────┴───────────────────┤
  │  Input Box | Send Button | File Upload                  │
  └─────────────────────────────────────────────────────────┘

Run:
  streamlit run app.py
"""

import os
import sys
import time
import logging
from pathlib import Path
from typing import List, Dict, Optional

import streamlit as st
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# ── Local module imports ─────────────────────────────────────────────────────
from pdf_loader import load_and_split_pdfs, load_uploaded_pdf, split_documents
from embeddings import build_vector_store, load_vector_store, update_vector_store, index_exists
from chatbot import chat
from related_questions import get_related_questions, detect_topic, get_all_topics

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="MES Fresher Assistant",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Custom CSS — Professional Dark/Light Theme
# ---------------------------------------------------------------------------
def inject_css(dark_mode: bool):
    if dark_mode:
        bg = "#0f1117"
        sidebar_bg = "#1a1d2e"
        card_bg = "#1e2132"
        border = "#2d3154"
        text = "#e8eaf6"
        muted = "#8892b0"
        accent = "#7c83fd"
        accent2 = "#64ffda"
        user_msg_bg = "#1e3a5f"
        bot_msg_bg = "#1a2744"
        input_bg = "#1e2132"
        btn_bg = "#7c83fd"
        tag_bg = "#2d3154"
        source_bg = "#1a2744"
    else:
        bg = "#f5f7ff"
        sidebar_bg = "#eef0fb"
        card_bg = "#ffffff"
        border = "#d0d4f7"
        text = "#1a1d2e"
        muted = "#6b7280"
        accent = "#5058e5"
        accent2 = "#00b894"
        user_msg_bg = "#dbeafe"
        bot_msg_bg = "#f0f4ff"
        input_bg = "#ffffff"
        btn_bg = "#5058e5"
        tag_bg = "#e8eaf6"
        source_bg = "#f0f4ff"

    st.markdown(f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Inter:wght@300;400;500;600;700&display=swap');

    /* ── Root ─────────────────────────────── */
    html, body, [data-testid="stAppViewContainer"] {{
        background-color: {bg} !important;
        color: {text} !important;
        font-family: 'Inter', sans-serif;
    }}
    [data-testid="stSidebar"] {{
        background-color: {sidebar_bg} !important;
        border-right: 1px solid {border};
    }}
    [data-testid="stSidebar"] * {{ color: {text} !important; }}
    
    /* ── Header ──────────────────────────── */
    .mes-header {{
        background: linear-gradient(135deg, {accent} 0%, #9c63ff 100%);
        padding: 18px 28px;
        border-radius: 14px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: 0 4px 24px rgba(92, 88, 229, 0.3);
    }}
    .mes-header h1 {{
        color: #ffffff !important;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
        letter-spacing: -0.02em;
    }}
    .mes-header .subtitle {{
        color: rgba(255,255,255,0.8);
        font-size: 0.82rem;
        margin-top: 2px;
    }}
    .header-badge {{
        background: rgba(255,255,255,0.2);
        color: #fff;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        border: 1px solid rgba(255,255,255,0.3);
    }}

    /* ── Chat Messages ────────────────────── */
    .msg-container {{
        display: flex;
        flex-direction: column;
        gap: 14px;
        padding: 8px 0;
    }}
    .msg-user {{
        background: {user_msg_bg};
        border: 1px solid {border};
        border-radius: 14px 14px 4px 14px;
        padding: 14px 18px;
        margin-left: 15%;
        font-size: 0.92rem;
        line-height: 1.6;
    }}
    .msg-bot {{
        background: {bot_msg_bg};
        border: 1px solid {border};
        border-radius: 14px 14px 14px 4px;
        padding: 16px 20px;
        margin-right: 8%;
        font-size: 0.92rem;
        line-height: 1.7;
    }}
    .msg-role-label {{
        font-size: 0.72rem;
        font-weight: 600;
        color: {accent};
        margin-bottom: 6px;
        letter-spacing: 0.05em;
        text-transform: uppercase;
    }}
    .msg-bot .msg-role-label {{ color: {accent2}; }}

    /* ── Source Badge ─────────────────────── */
    .source-chip {{
        display: inline-block;
        background: {source_bg};
        border: 1px solid {border};
        border-radius: 6px;
        padding: 2px 10px;
        font-size: 0.72rem;
        font-family: 'JetBrains Mono', monospace;
        color: {muted};
        margin: 6px 4px 0 0;
    }}

    /* ── Related Questions Panel ──────────── */
    .rq-panel {{
        background: {card_bg};
        border: 1px solid {border};
        border-radius: 14px;
        padding: 16px;
        position: sticky;
        top: 80px;
    }}
    .rq-title {{
        font-size: 0.78rem;
        font-weight: 700;
        color: {accent};
        letter-spacing: 0.08em;
        text-transform: uppercase;
        margin-bottom: 12px;
        padding-bottom: 8px;
        border-bottom: 2px solid {border};
    }}
    .rq-topic-badge {{
        display: inline-block;
        background: {tag_bg};
        color: {accent};
        font-size: 0.7rem;
        font-weight: 700;
        padding: 2px 10px;
        border-radius: 12px;
        margin-bottom: 12px;
        letter-spacing: 0.05em;
        border: 1px solid {border};
    }}
    .rq-item {{
        background: {tag_bg};
        border: 1px solid {border};
        border-radius: 10px;
        padding: 10px 14px;
        margin: 6px 0;
        font-size: 0.83rem;
        cursor: pointer;
        transition: all 0.2s ease;
        color: {text};
        line-height: 1.4;
    }}
    .rq-item:hover {{
        border-color: {accent};
        background: {bot_msg_bg};
        transform: translateX(2px);
    }}

    /* ── Sidebar Cards ───────────────────── */
    .sidebar-section {{
        background: {card_bg};
        border: 1px solid {border};
        border-radius: 12px;
        padding: 14px;
        margin-bottom: 14px;
    }}
    .sidebar-section-title {{
        font-size: 0.72rem;
        font-weight: 700;
        color: {accent};
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-bottom: 10px;
    }}
    .history-item {{
        font-size: 0.78rem;
        color: {muted};
        padding: 5px 0;
        border-bottom: 1px solid {border};
        cursor: pointer;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .history-item:last-child {{ border-bottom: none; }}

    /* ── Status Indicators ───────────────── */
    .status-dot-green {{ color: #00e676; }}
    .status-dot-red {{ color: #ff5252; }}
    .status-dot-yellow {{ color: #ffea00; }}

    /* ── Streamlit overrides ─────────────── */
    .stTextArea textarea {{
        background-color: {input_bg} !important;
        color: {text} !important;
        border: 1px solid {border} !important;
        border-radius: 10px !important;
        font-family: 'Inter', sans-serif !important;
        font-size: 0.92rem !important;
    }}
    .stTextArea textarea:focus {{
        border-color: {accent} !important;
        box-shadow: 0 0 0 2px {accent}33 !important;
    }}
    .stButton button {{
        background: linear-gradient(135deg, {btn_bg}, #9c63ff) !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 10px !important;
        font-weight: 600 !important;
        font-size: 0.9rem !important;
        padding: 10px 20px !important;
        transition: opacity 0.2s ease !important;
    }}
    .stButton button:hover {{ opacity: 0.88 !important; }}
    div[data-testid="stFileUploader"] {{
        background: {card_bg} !important;
        border: 1px dashed {border} !important;
        border-radius: 10px !important;
    }}
    /* Remove default Streamlit padding */
    .block-container {{ padding-top: 1rem !important; }}
    footer {{ display: none !important; }}
    #MainMenu {{ display: none !important; }}
    </style>
    """, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Session State Initialisation
# ---------------------------------------------------------------------------
def init_session():
    defaults = {
        "chat_history": [],           # List[Dict] — full conversation
        "vector_store": None,         # FAISS instance
        "kb_loaded": False,           # whether knowledge base is ready
        "kb_sources": [],             # list of loaded PDF names
        "dark_mode": True,            # theme toggle
        "related_questions": [],      # current related questions
        "current_topic": "GENERAL",   # detected topic of last query
        "api_key": os.getenv("OPENAI_API_KEY", ""),
        "model": "gpt-4o-mini",
        "show_sources": True,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


# ---------------------------------------------------------------------------
# Knowledge Base Loading
# ---------------------------------------------------------------------------
def load_knowledge_base(data_dir: str = "./data", force_rebuild: bool = False):
    """Load PDFs from data/ and build/load FAISS index."""
    api_key = st.session_state.api_key
    if not api_key:
        st.error("⚠️ Please enter your OpenAI API key in the sidebar Settings.")
        return

    with st.spinner("📚 Loading knowledge base..."):
        try:
            # Try loading existing index first (faster)
            if not force_rebuild and index_exists():
                vs = load_vector_store(api_key=api_key)
                if vs:
                    st.session_state.vector_store = vs
                    st.session_state.kb_loaded = True
                    # List PDFs in data/
                    pdfs = list(Path(data_dir).glob("*.pdf")) if Path(data_dir).exists() else []
                    st.session_state.kb_sources = [p.name for p in pdfs]
                    st.success(f"✅ Knowledge base loaded from cache ({len(st.session_state.kb_sources)} document(s)).")
                    return

            # Build from scratch
            chunks = load_and_split_pdfs(data_dir=data_dir)
            if not chunks:
                st.warning(
                    "📂 No PDFs found in the `data/` folder.\n\n"
                    "Place your `.pdf` files inside `./data/` and reload, "
                    "or upload a file using the upload panel."
                )
                st.session_state.kb_loaded = False
                return

            vs = build_vector_store(chunks, api_key=api_key)
            st.session_state.vector_store = vs
            st.session_state.kb_loaded = True
            pdfs = list(Path(data_dir).glob("*.pdf"))
            st.session_state.kb_sources = [p.name for p in pdfs]
            st.success(f"✅ Knowledge base built from {len(pdfs)} document(s).")

        except Exception as e:
            st.error(f"❌ Failed to load knowledge base: {e}")
            logger.error(f"Knowledge base load error: {e}", exc_info=True)


def handle_pdf_upload(uploaded_files):
    """Process newly uploaded PDFs and add to vector store."""
    api_key = st.session_state.api_key
    if not api_key:
        st.error("⚠️ Enter your OpenAI API key first.")
        return

    for uploaded_file in uploaded_files:
        with st.spinner(f"Processing {uploaded_file.name}..."):
            try:
                doc = load_uploaded_pdf(uploaded_file)
                chunks = split_documents([doc])

                if st.session_state.vector_store is None:
                    vs = build_vector_store(chunks, api_key=api_key)
                    st.session_state.vector_store = vs
                else:
                    update_vector_store(st.session_state.vector_store, chunks)

                st.session_state.kb_loaded = True
                if uploaded_file.name not in st.session_state.kb_sources:
                    st.session_state.kb_sources.append(uploaded_file.name)

                st.success(f"✅ Added: {uploaded_file.name}")
            except Exception as e:
                st.error(f"❌ Error processing {uploaded_file.name}: {e}")


# ---------------------------------------------------------------------------
# Chat Logic
# ---------------------------------------------------------------------------
def handle_send(query: str):
    """Process a user query and generate a response."""
    if not query.strip():
        return
    if not st.session_state.api_key:
        st.error("⚠️ Please enter your OpenAI API key in the sidebar Settings.")
        return

    # Add user message to history
    st.session_state.chat_history.append({"role": "user", "content": query})

    # Generate response
    with st.spinner("🤔 Thinking..."):
        result = chat(
            query=query,
            vector_store=st.session_state.vector_store,
            chat_history=st.session_state.chat_history[:-1],  # exclude current msg
            api_key=st.session_state.api_key,
            model=st.session_state.model,
        )

    # Add assistant response
    st.session_state.chat_history.append({
        "role": "assistant",
        "content": result["answer"],
        "sources": result.get("sources", []),
        "has_context": result.get("has_context", False),
    })

    # Detect topic + update related questions
    topic, _ = detect_topic(query)
    st.session_state.current_topic = topic
    st.session_state.related_questions = get_related_questions(query, topic=topic)


# ---------------------------------------------------------------------------
# UI Components
# ---------------------------------------------------------------------------

def render_header():
    st.markdown("""
    <div class="mes-header">
        <div>
            <h1>🏭 MES Fresher Assistant</h1>
            <div class="subtitle">Your intelligent onboarding companion for Manufacturing Execution Systems</div>
        </div>
        <div class="header-badge">AI-Powered RAG</div>
    </div>
    """, unsafe_allow_html=True)


def render_sidebar():
    with st.sidebar:
        st.markdown('<div class="sidebar-section-title">⚙️ Configuration</div>', unsafe_allow_html=True)

        # Dark mode toggle
        dark = st.toggle("🌙 Dark Mode", value=st.session_state.dark_mode, key="dark_toggle")
        if dark != st.session_state.dark_mode:
            st.session_state.dark_mode = dark
            st.rerun()

        st.divider()

        # ── Settings ──────────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-title">🔑 Settings</div>', unsafe_allow_html=True)
        with st.container():
            api_input = st.text_input(
                "OpenAI API Key",
                value=st.session_state.api_key,
                type="password",
                placeholder="sk-...",
                help="Your OpenAI API key. Get it from platform.openai.com",
            )
            if api_input != st.session_state.api_key:
                st.session_state.api_key = api_input

            model = st.selectbox(
                "Model",
                options=["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"],
                index=0,
                help="gpt-4o-mini is recommended for speed and cost.",
            )
            st.session_state.model = model

            st.session_state.show_sources = st.checkbox(
                "Show source documents", value=st.session_state.show_sources
            )

        st.divider()

        # ── Knowledge Base ─────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-title">📚 Knowledge Base</div>', unsafe_allow_html=True)

        kb_status = "🟢 Ready" if st.session_state.kb_loaded else "🔴 Not Loaded"
        st.markdown(f"**Status:** {kb_status}")

        if st.session_state.kb_sources:
            with st.expander(f"📄 {len(st.session_state.kb_sources)} Document(s) Loaded"):
                for src in st.session_state.kb_sources:
                    st.markdown(f"• `{src}`")

        col1, col2 = st.columns(2)
        with col1:
            if st.button("📥 Load PDFs", use_container_width=True):
                load_knowledge_base()
        with col2:
            if st.button("🔄 Rebuild", use_container_width=True):
                load_knowledge_base(force_rebuild=True)

        st.divider()

        # ── Upload PDFs ────────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-title">📤 Upload Documents</div>', unsafe_allow_html=True)
        uploaded = st.file_uploader(
            "Upload PDF files",
            type=["pdf"],
            accept_multiple_files=True,
            label_visibility="collapsed",
        )
        if uploaded:
            if st.button("➕ Add to Knowledge Base", use_container_width=True):
                handle_pdf_upload(uploaded)

        st.divider()

        # ── Chat History Summary ───────────────────────────────────────────
        st.markdown('<div class="sidebar-section-title">💬 Recent Questions</div>', unsafe_allow_html=True)
        user_msgs = [m for m in st.session_state.chat_history if m["role"] == "user"]
        if user_msgs:
            for msg in user_msgs[-6:][::-1]:
                st.markdown(
                    f'<div class="history-item">• {msg["content"][:55]}{"..." if len(msg["content"]) > 55 else ""}</div>',
                    unsafe_allow_html=True,
                )
        else:
            st.markdown('<span style="color:#8892b0;font-size:0.8rem;">No conversation yet.</span>', unsafe_allow_html=True)

        st.divider()

        # ── Tools ──────────────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-title">🛠️ Tools</div>', unsafe_allow_html=True)
        if st.button("🗑️ Clear Chat History", use_container_width=True):
            st.session_state.chat_history = []
            st.session_state.related_questions = []
            st.session_state.current_topic = "GENERAL"
            st.rerun()

        st.markdown("""
        <div style="margin-top:20px;padding:12px;background:rgba(124,131,253,0.08);border-radius:10px;border:1px solid rgba(124,131,253,0.2);">
            <div style="font-size:0.72rem;color:#8892b0;text-align:center;">
                MES Fresher Assistant v1.0<br>
                <span style="color:#7c83fd;">Powered by OpenAI + LangChain + FAISS</span>
            </div>
        </div>
        """, unsafe_allow_html=True)


def render_chat_panel():
    """Render the center chat panel with message history."""
    chat_container = st.container()

    with chat_container:
        if not st.session_state.chat_history:
            # Welcome screen
            st.markdown("""
            <div style="text-align:center;padding:48px 20px;opacity:0.7;">
                <div style="font-size:3rem;margin-bottom:12px;">🏭</div>
                <div style="font-size:1.2rem;font-weight:600;margin-bottom:8px;">Welcome to MES Fresher Assistant!</div>
                <div style="font-size:0.9rem;max-width:420px;margin:0 auto;line-height:1.6;">
                    Ask me anything about MES systems, workflows, error codes, KPIs, DISS, SIM, and more.
                    I'm here to help you get up to speed quickly!
                </div>
                <div style="margin-top:20px;font-size:0.8rem;opacity:0.6;">
                    💡 Tip: Load your company PDFs from the sidebar for context-aware answers.
                </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            for msg in st.session_state.chat_history:
                if msg["role"] == "user":
                    st.markdown(f"""
                    <div class="msg-user">
                        <div class="msg-role-label">👤 You</div>
                        {msg["content"]}
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    # Bot message
                    sources_html = ""
                    if st.session_state.show_sources and msg.get("sources"):
                        chips = "".join(
                            f'<span class="source-chip">📄 {s}</span>'
                            for s in msg["sources"]
                        )
                        sources_html = f'<div style="margin-top:10px;">{chips}</div>'

                    # Render markdown in bot response properly
                    st.markdown(f"""
                    <div class="msg-bot">
                        <div class="msg-role-label">🤖 MES Assistant</div>
                    </div>
                    """, unsafe_allow_html=True)
                    # Use st.markdown for proper rendering of bold/bullets
                    st.markdown(msg["content"])
                    if sources_html:
                        st.markdown(sources_html, unsafe_allow_html=True)


def render_related_questions():
    """Render the right-side related questions panel."""
    st.markdown("""
    <div class="rq-title">💡 Related Questions</div>
    """, unsafe_allow_html=True)

    topic = st.session_state.current_topic
    questions = st.session_state.related_questions

    if topic and topic != "GENERAL":
        st.markdown(f'<div class="rq-topic-badge">🏷️ {topic}</div>', unsafe_allow_html=True)

    if not questions:
        # Default starter questions
        questions = [
            "What is MES and how does it work?",
            "How do I read a KPI dashboard?",
            "What are common MES error codes?",
            "How does DISS module function?",
        ]
        st.markdown('<div style="font-size:0.75rem;color:#8892b0;margin-bottom:8px;">Starter questions:</div>', unsafe_allow_html=True)

    for q in questions:
        if st.button(q, key=f"rq_{q[:40]}", use_container_width=True):
            handle_send(q)
            st.rerun()

    # Topic browser
    st.markdown("---")
    st.markdown('<div class="rq-title" style="margin-top:8px;">🗂️ Browse by Topic</div>', unsafe_allow_html=True)
    all_topics = get_all_topics()
    selected_topic = st.selectbox(
        "Select topic",
        options=["— Select —"] + all_topics,
        label_visibility="collapsed",
        key="topic_browser",
    )
    if selected_topic and selected_topic != "— Select —":
        from related_questions import get_questions_for_topic
        topic_qs = get_questions_for_topic(selected_topic)[:4]
        for q in topic_qs:
            if st.button(q, key=f"tb_{q[:40]}", use_container_width=True):
                handle_send(q)
                st.rerun()


def render_input_panel():
    """Render the bottom input area."""
    st.markdown("---")
    col_input, col_btn = st.columns([5, 1])

    with col_input:
        user_input = st.text_area(
            "Ask a question...",
            placeholder="e.g. What is DISS? / Explain error code 3002 / How is KPI calculated?",
            height=68,
            label_visibility="collapsed",
            key="chat_input",
        )

    with col_btn:
        st.markdown("<br>", unsafe_allow_html=True)
        send = st.button("Send ➤", use_container_width=True, key="send_btn")

    if send and user_input.strip():
        handle_send(user_input.strip())
        st.rerun()

    # Keyboard shortcut hint
    st.markdown(
        '<div style="font-size:0.72rem;color:#8892b0;text-align:right;margin-top:-8px;">'
        'Click Send or press Ctrl+Enter</div>',
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Main App
# ---------------------------------------------------------------------------
def main():
    init_session()
    inject_css(st.session_state.dark_mode)

    render_header()
    render_sidebar()

    # ── Three-column layout ────────────────────────────────────────────────
    # Note: Streamlit doesn't support a true right-sidebar, so we simulate
    # the layout using columns in the main content area.
    chat_col, rq_col = st.columns([3, 1])

    with chat_col:
        render_chat_panel()
        render_input_panel()

    with rq_col:
        render_related_questions()

    # Auto-load knowledge base on first run if data/ exists and has PDFs
    data_dir = "./data"
    if (
        not st.session_state.kb_loaded
        and Path(data_dir).exists()
        and any(Path(data_dir).glob("*.pdf"))
        and st.session_state.api_key
    ):
        load_knowledge_base(data_dir=data_dir)


if __name__ == "__main__":
    main()
