"""
related_questions.py
--------------------
Context-aware Related Questions Engine for the MES Fresher Assistant.

Architecture:
  User Query
      ↓
  Topic Detection (keyword matching + intent classification)
      ↓
  Question Bank Lookup (scalable dictionary-based)
      ↓
  Keyword Filtering (ensure strict topic relevance)
      ↓
  Related Questions List (4 questions max)

Future enhancement: semantic similarity using sentence-transformers.
"""

import re
import logging
from typing import List, Tuple, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Question Bank
# Scalable dictionary: topic → list of follow-up questions
# Add new topics by appending entries here — no other code changes needed.
# ---------------------------------------------------------------------------

QUESTION_BANK: dict[str, List[str]] = {
    "DISS": [
        "What are the main modules of DISS?",
        "How does DISS integrate with other MES components?",
        "What is the DISS architecture?",
        "What features does DISS provide for freshers?",
        "How do I access DISS for the first time?",
        "What are common DISS error codes and their meanings?",
        "How is data flow managed in DISS?",
    ],
    "KPI": [
        "How are KPIs calculated in the MES system?",
        "How do I configure KPI dashboards?",
        "What are the standard KPIs tracked in MES?",
        "What is the difference between real-time and historical KPIs?",
        "Who is responsible for KPI reporting?",
        "How do KPIs relate to OEE metrics?",
    ],
    "SIM": [
        "What does SIM stand for in MES context?",
        "How does the SIM module work?",
        "How is SIM configured for a new production line?",
        "What events trigger SIM alerts?",
        "How does SIM interact with SCADA systems?",
        "What are common SIM troubleshooting steps?",
    ],
    "WIP": [
        "What is Work-in-Progress (WIP) tracking?",
        "How does WIP status get updated in real time?",
        "What causes WIP discrepancies in MES?",
        "How do I generate a WIP report?",
        "How does WIP data feed into production scheduling?",
        "What are WIP hold and release procedures?",
    ],
    "BOM": [
        "What is a Bill of Materials (BOM) in MES?",
        "How do I create or edit a BOM?",
        "What is the difference between engineering BOM and manufacturing BOM?",
        "How does BOM revision control work?",
        "What happens when a BOM is updated mid-production?",
        "How does BOM integrate with ERP systems?",
    ],
    "ERP": [
        "How does MES integrate with ERP systems?",
        "What data is exchanged between MES and ERP?",
        "What is the role of ERP in shop-floor execution?",
        "How are work orders synchronized between ERP and MES?",
        "What are common ERP-MES integration challenges?",
        "How do I troubleshoot ERP data sync issues?",
    ],
    "SAP": [
        "How does MES connect to SAP?",
        "What SAP modules are used alongside MES?",
        "How are production orders created and released from SAP?",
        "What is SAP PP and how does it relate to MES?",
        "How do I resolve SAP-MES data mismatch errors?",
        "What are the steps for SAP goods movement confirmation?",
    ],
    "MES": [
        "What are the core modules of an MES system?",
        "What is the difference between MES and SCADA?",
        "How does MES improve production efficiency?",
        "What standards govern MES implementations (ISA-95)?",
        "How is MES connected to ERP and PLCs?",
        "What data does MES collect from the shop floor?",
    ],
    "SCADA": [
        "What is the difference between SCADA and MES?",
        "How does SCADA communicate with PLCs?",
        "What are common SCADA alarm types?",
        "How does SCADA data feed into MES?",
        "What is an HMI and how does it relate to SCADA?",
        "How do I read SCADA trend data?",
    ],
    "PLC": [
        "What is a PLC and how is it used in manufacturing?",
        "How does PLC communicate with MES?",
        "What programming languages are used for PLCs?",
        "How do I interpret PLC fault codes?",
        "What is the difference between PLC and DCS?",
        "How is PLC I/O mapped in MES configurations?",
    ],
    "OEE": [
        "What are the three components of OEE?",
        "How is OEE calculated step by step?",
        "What is considered a good OEE score?",
        "How does MES collect OEE data automatically?",
        "How do I improve Availability in OEE metrics?",
        "What is the difference between OEE and TEEP?",
    ],
    "SPC": [
        "What is Statistical Process Control (SPC)?",
        "How are control charts used in SPC?",
        "What does an out-of-control signal mean in SPC?",
        "How does MES implement SPC monitoring?",
        "What is Cp and Cpk in process capability?",
        "How are SPC alerts configured in MES?",
    ],
    "NCR": [
        "What is an NCR (Non-Conformance Report)?",
        "How do I raise an NCR in the system?",
        "What is the NCR workflow from creation to closure?",
        "Who approves and closes NCRs?",
        "How are NCRs linked to corrective actions (CAPA)?",
        "How do I search for historical NCRs?",
    ],
    "ECO": [
        "What is an Engineering Change Order (ECO)?",
        "How does an ECO affect production in progress?",
        "What is the ECO approval workflow?",
        "How are ECOs tracked in MES?",
        "What is the difference between an ECO and an ECN?",
        "How do I implement an ECO on the shop floor?",
    ],
    "FMEA": [
        "What is Failure Mode and Effects Analysis (FMEA)?",
        "How is FMEA used in the MES quality module?",
        "What is an RPN score in FMEA?",
        "When should a FMEA be reviewed and updated?",
        "What is the difference between DFMEA and PFMEA?",
        "How do FMEA findings link to process controls in MES?",
    ],
    "MAINTENANCE": [
        "How is preventive maintenance scheduled in MES?",
        "How do I raise a maintenance work order?",
        "What is predictive maintenance and how is it supported?",
        "How are maintenance records stored in MES?",
        "What triggers an automatic maintenance alert?",
        "How does downtime from maintenance get reported in OEE?",
    ],
    "QUALITY": [
        "What quality checks are available in MES?",
        "How is in-process quality inspection configured?",
        "How does MES handle failed quality inspections?",
        "What is a quality hold and how do I apply one?",
        "How are quality metrics reported to management?",
        "How does MES integrate with quality management systems (QMS)?",
    ],
    "PRODUCTION": [
        "How is a production order created and released?",
        "How do I track production progress in real time?",
        "What is the production scheduling module?",
        "How are production targets set in MES?",
        "How does MES handle production line changeovers?",
        "How are production losses categorized and tracked?",
    ],
    "INVENTORY": [
        "How does MES track raw material inventory?",
        "What triggers an inventory replenishment request?",
        "How is scrap and waste recorded in inventory?",
        "How does MES support FIFO/FEFO inventory management?",
        "How are inventory discrepancies investigated?",
        "How does MES sync inventory data with the ERP?",
    ],
    "REPORTING": [
        "What standard reports are available in MES?",
        "How do I create a custom report in MES?",
        "How do I schedule automated report delivery?",
        "What data sources can be included in MES reports?",
        "How are shift reports generated at the end of shift?",
        "How do I export a report to Excel or PDF?",
    ],
    "TRAINING": [
        "What training resources are available for MES freshers?",
        "How long is the MES onboarding program?",
        "Who is the point of contact for training queries?",
        "What certifications are recommended for MES engineers?",
        "How do I access the MES knowledge base?",
        "What are the most important MES concepts to learn first?",
    ],
}

# ---------------------------------------------------------------------------
# Topic → Keyword Mapping
# Used for keyword-based topic detection from user queries
# ---------------------------------------------------------------------------

TOPIC_KEYWORDS: dict[str, List[str]] = {
    "DISS": ["diss", "distribution", "dispatch"],
    "KPI": ["kpi", "key performance", "performance indicator", "metric"],
    "SIM": ["sim", "simulation", "simulate"],
    "WIP": ["wip", "work in progress", "work-in-progress", "in process"],
    "BOM": ["bom", "bill of material", "bill of materials"],
    "ERP": ["erp", "enterprise resource", "resource planning"],
    "SAP": ["sap", "sap pp", "sap mm", "sap qm"],
    "MES": ["mes", "manufacturing execution", "execution system"],
    "SCADA": ["scada", "supervisory control", "data acquisition"],
    "PLC": ["plc", "programmable logic", "ladder logic", "controller"],
    "OEE": ["oee", "overall equipment", "equipment effectiveness", "availability", "performance", "quality rate"],
    "SPC": ["spc", "statistical process", "control chart", "cpk", "capability"],
    "NCR": ["ncr", "non conformance", "non-conformance", "nonconformance", "deviation"],
    "ECO": ["eco", "engineering change", "change order"],
    "FMEA": ["fmea", "failure mode", "effects analysis", "rpn"],
    "MAINTENANCE": ["maintenance", "preventive", "predictive", "breakdown", "pm", "work order"],
    "QUALITY": ["quality", "inspection", "qc", "defect", "rework", "reject"],
    "PRODUCTION": ["production", "schedule", "work order", "shop floor", "line"],
    "INVENTORY": ["inventory", "stock", "material", "warehouse", "replenish"],
    "REPORTING": ["report", "dashboard", "analytics", "export", "shift report"],
    "TRAINING": ["training", "onboard", "learn", "guide", "fresher", "new employee"],
}

# Priority order — more specific topics checked before generic ones
TOPIC_PRIORITY = [
    "DISS", "KPI", "SIM", "WIP", "BOM", "SAP", "SCADA", "PLC",
    "OEE", "SPC", "NCR", "ECO", "FMEA", "MAINTENANCE", "QUALITY",
    "PRODUCTION", "INVENTORY", "REPORTING", "TRAINING", "ERP", "MES",
]


# ---------------------------------------------------------------------------
# Topic Detection
# ---------------------------------------------------------------------------

def detect_topic(query: str) -> Tuple[str, float]:
    """
    Detect the primary MES topic from a user query using keyword matching.

    Args:
        query: Raw user query string.

    Returns:
        Tuple of (topic_code, confidence_score).
        confidence_score is 1.0 for exact match, 0.5 for partial.
    """
    query_lower = query.lower()

    # Remove punctuation for cleaner matching
    query_clean = re.sub(r"[^\w\s]", " ", query_lower)

    best_topic = "GENERAL"
    best_score = 0.0

    for topic in TOPIC_PRIORITY:
        keywords = TOPIC_KEYWORDS.get(topic, [])
        for keyword in keywords:
            if keyword in query_clean:
                # Longer keyword match → higher confidence
                score = len(keyword.split()) / max(len(query_clean.split()), 1)
                score = min(score + 0.5, 1.0)  # base boost so partial matches still register
                if score > best_score:
                    best_score = score
                    best_topic = topic

    logger.debug(f"Topic detected: {best_topic} (confidence: {best_score:.2f}) for query: '{query[:60]}'")
    return best_topic, best_score


# ---------------------------------------------------------------------------
# Related Questions Generator
# ---------------------------------------------------------------------------

def get_related_questions(
    query: str,
    topic: Optional[str] = None,
    max_questions: int = 4,
) -> List[str]:
    """
    Generate context-aware related questions based on the user's query.

    Strategy:
    1. Detect topic from query (or use provided topic override)
    2. Look up the question bank for that topic
    3. Filter out any question too similar to the current query
    4. Return up to max_questions questions

    Args:
        query: The user's current question.
        topic: Optional pre-detected topic to skip detection.
        max_questions: Maximum number of questions to return.

    Returns:
        List of related question strings (strictly topic-relevant).
    """
    detected_topic = topic or detect_topic(query)[0]

    if detected_topic == "GENERAL":
        # Fallback: return generic MES onboarding questions
        return _get_general_questions(max_questions)

    # Fetch questions for the detected topic
    candidate_questions = QUESTION_BANK.get(detected_topic, [])

    if not candidate_questions:
        logger.warning(f"No question bank entry for topic: {detected_topic}")
        return _get_general_questions(max_questions)

    # Filter out questions too similar to the current query
    query_words = set(re.sub(r"[^\w\s]", "", query.lower()).split())
    filtered = []

    for q in candidate_questions:
        q_words = set(re.sub(r"[^\w\s]", "", q.lower()).split())
        # Overlap ratio — if >80% words match, it's too similar to the query
        overlap = len(query_words & q_words) / max(len(query_words), 1)
        if overlap < 0.8:
            filtered.append(q)

    # Return up to max_questions, maintaining natural order
    result = filtered[:max_questions]

    logger.info(f"Related questions for topic '{detected_topic}': {len(result)} returned.")
    return result


def _get_general_questions(max_questions: int = 4) -> List[str]:
    """Return generic onboarding questions when no specific topic is detected."""
    general = [
        "What is MES and how does it help manufacturing?",
        "What are the main modules in an MES system?",
        "How do I navigate the MES dashboard?",
        "Who should I contact for MES support?",
        "What are the most common MES error codes?",
        "How does MES connect to the shop floor equipment?",
    ]
    return general[:max_questions]


# ---------------------------------------------------------------------------
# Utility: Get all available topics
# ---------------------------------------------------------------------------

def get_all_topics() -> List[str]:
    """Return a list of all supported topic codes."""
    return list(QUESTION_BANK.keys())


def get_questions_for_topic(topic: str) -> List[str]:
    """Return all questions for a given topic (useful for UI dropdowns)."""
    return QUESTION_BANK.get(topic.upper(), [])
