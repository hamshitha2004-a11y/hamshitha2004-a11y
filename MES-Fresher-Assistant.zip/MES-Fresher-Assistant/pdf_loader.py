"""
pdf_loader.py
-------------
Handles loading, reading, and chunking of PDF documents for the RAG pipeline.

Pipeline:
  PDF Files → Text Extraction → Text Chunking → Chunks (ready for embedding)
"""

import os
import logging
from pathlib import Path
from typing import List

from pypdf import PdfReader
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_DATA_DIR = "./data"
CHUNK_SIZE = 1000          # characters per chunk
CHUNK_OVERLAP = 200        # overlap between adjacent chunks (preserves context)


# ---------------------------------------------------------------------------
# PDF Text Extraction
# ---------------------------------------------------------------------------

def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Extract all text from a single PDF file using PyPDF.

    Args:
        pdf_path: Absolute or relative path to the .pdf file.

    Returns:
        Full extracted text as a single string.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the PDF has no extractable text (e.g. scanned image PDF).
    """
    path = Path(pdf_path)
    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    logger.info(f"Extracting text from: {path.name}")

    try:
        reader = PdfReader(str(path))
        pages_text = []

        for page_num, page in enumerate(reader.pages, start=1):
            text = page.extract_text()
            if text:
                pages_text.append(text)
            else:
                logger.warning(f"  Page {page_num} in '{path.name}' returned no text (possibly an image).")

        full_text = "\n\n".join(pages_text)

        if not full_text.strip():
            raise ValueError(
                f"No extractable text found in '{path.name}'. "
                "This may be a scanned/image-based PDF — OCR is required."
            )

        logger.info(f"  ✓ Extracted {len(full_text):,} characters from {len(reader.pages)} pages.")
        return full_text

    except Exception as e:
        logger.error(f"  ✗ Failed to extract text from '{path.name}': {e}")
        raise


# ---------------------------------------------------------------------------
# Multi-PDF Loader
# ---------------------------------------------------------------------------

def load_pdfs_from_directory(data_dir: str = DEFAULT_DATA_DIR) -> List[Document]:
    """
    Load all PDF files from a directory and return a list of LangChain Documents.
    Each Document represents one PDF with metadata (source filename).

    Args:
        data_dir: Path to the folder containing .pdf files.

    Returns:
        List of LangChain Document objects.
    """
    data_path = Path(data_dir)
    if not data_path.exists():
        logger.warning(f"Data directory '{data_dir}' not found. Creating it...")
        data_path.mkdir(parents=True, exist_ok=True)
        return []

    pdf_files = sorted(data_path.glob("*.pdf"))
    if not pdf_files:
        logger.warning(f"No PDF files found in '{data_dir}'.")
        return []

    documents: List[Document] = []

    for pdf_file in pdf_files:
        try:
            text = extract_text_from_pdf(str(pdf_file))
            doc = Document(
                page_content=text,
                metadata={
                    "source": pdf_file.name,
                    "file_path": str(pdf_file),
                    "file_size_kb": round(pdf_file.stat().st_size / 1024, 1),
                }
            )
            documents.append(doc)
        except Exception as e:
            logger.error(f"Skipping '{pdf_file.name}': {e}")
            continue

    logger.info(f"✓ Loaded {len(documents)} PDF document(s) from '{data_dir}'.")
    return documents


def load_uploaded_pdf(uploaded_file, temp_dir: str = "./temp_uploads") -> Document:
    """
    Load a PDF uploaded via Streamlit's file_uploader widget.

    Args:
        uploaded_file: Streamlit UploadedFile object.
        temp_dir: Directory to temporarily save the uploaded file.

    Returns:
        A LangChain Document.
    """
    temp_path = Path(temp_dir)
    temp_path.mkdir(parents=True, exist_ok=True)

    save_path = temp_path / uploaded_file.name
    with open(save_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    logger.info(f"Saved uploaded file to: {save_path}")

    text = extract_text_from_pdf(str(save_path))
    return Document(
        page_content=text,
        metadata={
            "source": uploaded_file.name,
            "file_path": str(save_path),
            "uploaded": True,
        }
    )


# ---------------------------------------------------------------------------
# Text Chunking
# ---------------------------------------------------------------------------

def split_documents(
    documents: List[Document],
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
) -> List[Document]:
    """
    Split a list of Documents into smaller chunks for embedding.

    Uses RecursiveCharacterTextSplitter which respects paragraph/sentence
    boundaries before falling back to character splits.

    Args:
        documents: List of full-text LangChain Documents.
        chunk_size: Maximum characters per chunk.
        chunk_overlap: Characters of overlap between consecutive chunks.

    Returns:
        List of chunked LangChain Documents (with inherited metadata).
    """
    if not documents:
        logger.warning("No documents to split.")
        return []

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""],  # preference order
    )

    chunks = splitter.split_documents(documents)
    logger.info(
        f"✓ Split {len(documents)} document(s) into {len(chunks)} chunks "
        f"(size≤{chunk_size}, overlap={chunk_overlap})."
    )
    return chunks


# ---------------------------------------------------------------------------
# Convenience: full load + split pipeline
# ---------------------------------------------------------------------------

def load_and_split_pdfs(
    data_dir: str = DEFAULT_DATA_DIR,
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
) -> List[Document]:
    """
    Full pipeline: load all PDFs from a directory, extract text, and split into chunks.

    Args:
        data_dir: Folder containing PDF files.
        chunk_size: Max chunk size in characters.
        chunk_overlap: Overlap in characters.

    Returns:
        List of chunked Documents ready for embedding.
    """
    documents = load_pdfs_from_directory(data_dir)
    if not documents:
        return []
    return split_documents(documents, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
