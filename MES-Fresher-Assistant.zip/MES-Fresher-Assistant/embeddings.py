"""
embeddings.py
-------------
Manages OpenAI Embeddings and the FAISS vector store.

Pipeline:
  Chunks → OpenAI Embeddings → FAISS Index → Retriever
"""

import os
import logging
from pathlib import Path
from typing import List, Optional

from langchain.schema import Document
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
FAISS_INDEX_DIR = "./faiss_index"          # local persistence directory
EMBEDDING_MODEL = "text-embedding-3-small" # cost-efficient OpenAI embedding model
RETRIEVER_TOP_K = 5                        # number of chunks to retrieve per query


# ---------------------------------------------------------------------------
# Embedding Model
# ---------------------------------------------------------------------------

def get_embedding_model(api_key: Optional[str] = None) -> OpenAIEmbeddings:
    """
    Initialise and return the OpenAI Embeddings model.

    Args:
        api_key: Optional API key override. Falls back to OPENAI_API_KEY env var.

    Returns:
        Configured OpenAIEmbeddings instance.
    """
    key = api_key or os.getenv("OPENAI_API_KEY")
    if not key:
        raise EnvironmentError(
            "OPENAI_API_KEY is not set. Add it to your .env file or environment variables."
        )

    return OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        openai_api_key=key,
    )


# ---------------------------------------------------------------------------
# FAISS Vector Store — Build
# ---------------------------------------------------------------------------

def build_vector_store(
    chunks: List[Document],
    api_key: Optional[str] = None,
    save_dir: str = FAISS_INDEX_DIR,
) -> FAISS:
    """
    Create a FAISS vector store from document chunks and persist it to disk.

    Args:
        chunks: List of chunked LangChain Documents.
        api_key: Optional OpenAI API key.
        save_dir: Directory to save the FAISS index.

    Returns:
        FAISS vector store instance.
    """
    if not chunks:
        raise ValueError("Cannot build vector store: no document chunks provided.")

    logger.info(f"Building FAISS index from {len(chunks)} chunks...")

    embeddings = get_embedding_model(api_key)

    # Create FAISS index
    vector_store = FAISS.from_documents(chunks, embeddings)

    # Persist to disk for reuse across sessions
    Path(save_dir).mkdir(parents=True, exist_ok=True)
    vector_store.save_local(save_dir)

    logger.info(f"✓ FAISS index built and saved to '{save_dir}'.")
    return vector_store


# ---------------------------------------------------------------------------
# FAISS Vector Store — Load
# ---------------------------------------------------------------------------

def load_vector_store(
    api_key: Optional[str] = None,
    load_dir: str = FAISS_INDEX_DIR,
) -> Optional[FAISS]:
    """
    Load an existing FAISS index from disk.

    Args:
        api_key: Optional OpenAI API key.
        load_dir: Directory where the FAISS index is stored.

    Returns:
        FAISS vector store instance, or None if no index exists.
    """
    index_path = Path(load_dir)

    if not index_path.exists() or not any(index_path.iterdir()):
        logger.info(f"No existing FAISS index found at '{load_dir}'.")
        return None

    try:
        embeddings = get_embedding_model(api_key)
        vector_store = FAISS.load_local(
            load_dir,
            embeddings,
            allow_dangerous_deserialization=True,  # required by LangChain ≥0.1
        )
        logger.info(f"✓ Loaded existing FAISS index from '{load_dir}'.")
        return vector_store
    except Exception as e:
        logger.error(f"Failed to load FAISS index: {e}")
        return None


# ---------------------------------------------------------------------------
# FAISS Vector Store — Update (add new documents)
# ---------------------------------------------------------------------------

def update_vector_store(
    vector_store: FAISS,
    new_chunks: List[Document],
    save_dir: str = FAISS_INDEX_DIR,
) -> FAISS:
    """
    Add new document chunks to an existing FAISS vector store and re-save.

    Args:
        vector_store: Existing FAISS instance.
        new_chunks: New chunks to add.
        save_dir: Directory to re-save the updated index.

    Returns:
        Updated FAISS vector store.
    """
    if not new_chunks:
        logger.warning("No new chunks to add.")
        return vector_store

    logger.info(f"Adding {len(new_chunks)} new chunks to existing FAISS index...")
    vector_store.add_documents(new_chunks)
    vector_store.save_local(save_dir)
    logger.info("✓ FAISS index updated and saved.")
    return vector_store


# ---------------------------------------------------------------------------
# Retriever
# ---------------------------------------------------------------------------

def get_retriever(vector_store: FAISS, top_k: int = RETRIEVER_TOP_K):
    """
    Create a LangChain retriever from the FAISS vector store.

    Args:
        vector_store: Initialised FAISS vector store.
        top_k: Number of most-relevant chunks to retrieve.

    Returns:
        LangChain VectorStoreRetriever.
    """
    return vector_store.as_retriever(
        search_type="similarity",
        search_kwargs={"k": top_k},
    )


# ---------------------------------------------------------------------------
# Check if index exists
# ---------------------------------------------------------------------------

def index_exists(index_dir: str = FAISS_INDEX_DIR) -> bool:
    """Return True if a FAISS index directory exists and contains files."""
    p = Path(index_dir)
    return p.exists() and any(p.iterdir())
