"""
chatbot.py
----------
Core RAG (Retrieval-Augmented Generation) chatbot engine.

Pipeline:
  User Query
      ↓
  FAISS Retriever → Relevant Chunks
      ↓
  Prompt Assembly (system + context + chat history + query)
      ↓
  OpenAI GPT (via LangChain)
      ↓
  Structured Answer
"""

import os
import logging
from typing import List, Dict, Optional, Tuple

from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, SystemMessage
from langchain_community.vectorstores import FAISS
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

from prompts import MES_SYSTEM_PROMPT
from embeddings import get_retriever

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_MODEL = "gpt-4o-mini"          # cost-efficient, fast
FALLBACK_MODEL = "gpt-3.5-turbo"
MAX_TOKENS = 1500
TEMPERATURE = 0.3                       # lower = more factual, consistent


# ---------------------------------------------------------------------------
# LLM Initialisation
# ---------------------------------------------------------------------------

def get_llm(
    api_key: Optional[str] = None,
    model: str = DEFAULT_MODEL,
    streaming: bool = False,
) -> ChatOpenAI:
    """
    Initialise and return a ChatOpenAI LLM instance.

    Args:
        api_key: Optional API key override.
        model: Model name to use.
        streaming: Enable streaming output (for future real-time UI).

    Returns:
        ChatOpenAI instance.
    """
    key = api_key or os.getenv("OPENAI_API_KEY")
    if not key:
        raise EnvironmentError("OPENAI_API_KEY is not set.")

    callbacks = [StreamingStdOutCallbackHandler()] if streaming else []

    return ChatOpenAI(
        model=model,
        openai_api_key=key,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS,
        callbacks=callbacks,
    )


# ---------------------------------------------------------------------------
# Context Retrieval
# ---------------------------------------------------------------------------

def retrieve_context(
    query: str,
    vector_store: FAISS,
    top_k: int = 5,
) -> Tuple[str, List[str]]:
    """
    Retrieve the most relevant document chunks for a query.

    Args:
        query: User's question.
        vector_store: Initialised FAISS vector store.
        top_k: Number of chunks to retrieve.

    Returns:
        Tuple of (formatted_context_string, list_of_source_filenames).
    """
    retriever = get_retriever(vector_store, top_k=top_k)

    try:
        docs = retriever.invoke(query)
    except Exception as e:
        logger.error(f"Retrieval failed: {e}")
        return "", []

    if not docs:
        return "", []

    # Format context with source attribution
    context_parts = []
    sources = []

    for i, doc in enumerate(docs, start=1):
        source = doc.metadata.get("source", "Unknown")
        if source not in sources:
            sources.append(source)
        context_parts.append(f"[Excerpt {i} — Source: {source}]\n{doc.page_content.strip()}")

    context = "\n\n---\n\n".join(context_parts)
    return context, sources


# ---------------------------------------------------------------------------
# Chat History Formatting
# ---------------------------------------------------------------------------

def format_chat_history(history: List[Dict[str, str]], max_turns: int = 6) -> str:
    """
    Format the recent chat history for inclusion in the prompt.

    Args:
        history: List of dicts with keys 'role' ('user'/'assistant') and 'content'.
        max_turns: Number of recent turns to include (keeps prompt size manageable).

    Returns:
        Formatted string of recent conversation.
    """
    if not history:
        return "No previous conversation."

    # Take only the most recent N turns
    recent = history[-(max_turns * 2):]  # each turn = user + assistant

    lines = []
    for msg in recent:
        role = "User" if msg["role"] == "user" else "Assistant"
        lines.append(f"{role}: {msg['content'][:500]}")  # truncate very long messages

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main Chat Function
# ---------------------------------------------------------------------------

def chat(
    query: str,
    vector_store: Optional[FAISS],
    chat_history: List[Dict[str, str]],
    api_key: Optional[str] = None,
    model: str = DEFAULT_MODEL,
) -> Dict[str, any]:
    """
    Main RAG chat function — retrieves context and generates a response.

    Args:
        query: User's question.
        vector_store: FAISS vector store (can be None if no PDFs loaded yet).
        chat_history: Conversation history list.
        api_key: Optional OpenAI API key.
        model: LLM model to use.

    Returns:
        Dict with keys:
            'answer'   : str — the generated response
            'sources'  : List[str] — source documents used
            'has_context': bool — whether RAG context was found
    """
    # ── Step 1: Retrieve context from knowledge base ────────────────────────
    context = ""
    sources = []
    has_context = False

    if vector_store is not None:
        context, sources = retrieve_context(query, vector_store)
        has_context = bool(context.strip())

    if not has_context:
        context = (
            "No relevant documentation was found for this query. "
            "Please answer based on general MES knowledge, and advise the user "
            "to check with their team lead or refer to official documentation."
        )

    # ── Step 2: Format chat history ──────────────────────────────────────────
    history_text = format_chat_history(chat_history)

    # ── Step 3: Build prompt ─────────────────────────────────────────────────
    prompt = MES_SYSTEM_PROMPT.format(
        context=context,
        chat_history=history_text,
        question=query,
    )

    # ── Step 4: Call LLM ─────────────────────────────────────────────────────
    try:
        llm = get_llm(api_key=api_key, model=model)
        messages = [HumanMessage(content=prompt)]
        response = llm.invoke(messages)
        answer = response.content.strip()

    except Exception as e:
        logger.error(f"LLM call failed: {e}")
        # Provide a graceful error message rather than crashing the UI
        answer = (
            "⚠️ **I encountered an error generating your response.**\n\n"
            f"Error details: `{str(e)}`\n\n"
            "Please check your OpenAI API key and ensure you have an active internet connection."
        )

    return {
        "answer": answer,
        "sources": sources,
        "has_context": has_context,
    }


# ---------------------------------------------------------------------------
# Simple Q&A (no RAG — for internal use / testing)
# ---------------------------------------------------------------------------

def simple_chat(
    query: str,
    system_prompt: str,
    api_key: Optional[str] = None,
    model: str = DEFAULT_MODEL,
    max_tokens: int = 300,
) -> str:
    """
    Lightweight chat call for internal tasks (topic detection, question generation).
    Does not use RAG or chat history.

    Args:
        query: The prompt/query to send.
        system_prompt: System instructions.
        api_key: Optional API key.
        model: Model name.
        max_tokens: Token limit.

    Returns:
        Raw response string.
    """
    key = api_key or os.getenv("OPENAI_API_KEY")
    if not key:
        raise EnvironmentError("OPENAI_API_KEY is not set.")

    llm = ChatOpenAI(
        model=model,
        openai_api_key=key,
        temperature=0.2,
        max_tokens=max_tokens,
    )

    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=query),
    ]

    response = llm.invoke(messages)
    return response.content.strip()
