# data/

Place your MES documentation PDF files here.

Examples:
- mes_user_guide.pdf
- kpi_handbook.pdf
- diss_module_docs.pdf
- error_codes_reference.pdf
- sop_manual.pdf

Then click "Load PDFs" in the sidebar to build the knowledge base.
